function DeleteFolder(TagId) {
    var socket = new WebSocket("ws://localhost:9292/FileSystem");
    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 3,
            Data: JSON.stringify({
                Path: document.getElementById("Path").value
            })
        }));
    };

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);
        var data = document.getElementById(TagId + '.data');
        if (result.Success)
        {
            var header = document.getElementById(TagId + '.header');


            header.innerHTML = "";
            data.innerHTML = "";
            data.innerHTML+= "Каталог успешно удален";
        }
        else {
            data.innerHTML = result.Message;
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}