function CreateCertRequest(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");
    socket.onopen = function () {      
        socket.send(JSON.stringify({
            Code: 1,
            Data: JSON.stringify({
                providerCode: document.getElementById("providerCode").value,
                providerName: document.getElementById("providerName").value,
                signTool: document.getElementById("signTool").value,
                certAttributes: ArrayKeyValue('oid', 'oid-value'), 
                enhKeyUsage: ArrayString('keys'),
                certPolicies: ArrayKeyValue('oid-polic', 'oid-value-polic'),
                certAltarnativeNames: ArrayKeyValueType('oid-alter', 'oid-value-alter', 'type-alter'),
                keyUsage: document.getElementById("keyUsage").value,
                notBefore: document.getElementById("notBefore").value,
                notAfter: document.getElementById("notAfter").value,
                containerName: document.getElementById("containerName").value,
                requestName: document.getElementById("requestName").value,
                exportableKey: document.getElementById("exportableKey").value
            })
        }));
    };
    

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);

        if (result.Success)
        {
            var header = document.getElementById(TagId + '.header');
            var data = document.getElementById(TagId + '.data');

            header.innerHTML = "";
            data.innerHTML = "";

            if (result.Data.length > 0)
            {
                header.innerHTML = makeHeader(result.Data[0]);

                result.Data.forEach((item) => {
                    data.innerHTML += makeDataLine(item);
            });
            }
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}