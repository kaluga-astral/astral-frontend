function CreateTokenCertRequest(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");
    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 8,
            Data: JSON.stringify({
                Pin: document.getElementById("Pin").value,
                TokenType: document.getElementById("TokenType").value,
                RequestData: JSON.stringify({
                    AbonentType: document.getElementById("AbonentType").value,
                    ContainerName: document.getElementById("ContainerName").value,
                    OGRNIP: document.getElementById("OGRNIP").value,
                    SNILS: document.getElementById("SNILS").value,
                    G: document.getElementById("G").value,
                    SN: document.getElementById("SN").value,
                    CN: document.getElementById("CN").value,
                    L: document.getElementById("L").value,
                    S: document.getElementById("S").value,
                    C: document.getElementById("C").value,
                    E: document.getElementById("E").value,
                    INN: document.getElementById("INN").value,
                    OGRN: document.getElementById("OGRN").value,
                    OU: document.getElementById("OU").value,
                    O: document.getElementById("O").value,
                    T: document.getElementById("T").value,
                    Street: document.getElementById("Street").value,
                    KPP: document.getElementById("KPP").value,
                    NotAfter: document.getElementById("NotAfter").value,
                })
            })
        }));
    };

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);

        if (result.Success)
        {
            var header = document.getElementById(TagId + '.header');
            var data = document.getElementById(TagId + '.data');

            header.innerHTML = "";
            data.innerHTML = "";

            if (result.Data.length > 0)
            {
                header.innerHTML = makeHeader(result.Data[0]);

                result.Data.forEach((item) => {
                    data.innerHTML += makeDataLine(item);
            });
            }
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}