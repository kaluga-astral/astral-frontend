function EncryptMsg(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");
    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 14,
            Data: JSON.stringify({
                Base64Data: document.getElementById("Base64Data").value,
                RecipientSubjectKeyIds: ArrayString('reci'),
                SenderSubjectKeyId: document.getElementById("SenderSubjectKeyId").value,
                Store : document.getElementById("Store").value,
                Flags: document.getElementById("Flags").value
            })
        }));

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);
		var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        if (result.Success)
        {
            header.innerHTML = "";
            data.innerHTML = "";
            data.innerHTML += result.Data;
        }
        else
        {
        	header.innerHTML = "";
            data.innerHTML = "";
        	data.innerHTML += "result: " + result.Success;
        	data.innerHTML += "\nmessage: " + result.Message;
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}
}