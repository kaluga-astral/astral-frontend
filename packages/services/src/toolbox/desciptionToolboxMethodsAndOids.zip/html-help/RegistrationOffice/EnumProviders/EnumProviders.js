function EnumProviders(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");

    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 11
        }));
    };
    
    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);

        if (result.Success) 
        {
            var header = document.getElementById(TagId + '.header');
            var data = document.getElementById(TagId + '.data');

            header.innerHTML = "";
            data.innerHTML = "";
            
            if (result.Data.length > 0)
            {
                header.innerHTML = makeHeader(result.Data[0]);
                
                result.Data.forEach((item) => {
                    data.innerHTML += makeDataLine(item);
                });
            }
        }
    };
    
    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');
        
        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}