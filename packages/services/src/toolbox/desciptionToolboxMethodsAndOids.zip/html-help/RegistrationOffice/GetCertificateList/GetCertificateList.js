function GetCertificateList(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");

    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 6
        }));
    };

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);
        var i = 0;
        if (result.Success)
        {
            var header = document.getElementById(TagId + '.header');
            var data = document.getElementById(TagId + '.data');

            header.innerHTML = "";
            data.innerHTML = "";

            if (result.Data.length > 0)
            {
                //header.innerHTML = makeHeader(result.Data[0]);

                result.Data.forEach((item) => {
                    i++;
                    data.innerHTML += "<tr><td><h4>Сертификат</h4></td><td><h4>  №" + i + "</h4></td></tr>" + makeKeyValueLine(item);

            });
            }
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}