﻿function GetDataSignature(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");
    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 7,
            Data: JSON.stringify({
                Base64Data: document.getElementById("Base64Data").value,
                SubjectKeyId: document.getElementById("SubjectKeyId").value
            })
        }));
    };

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        if (result.Success)
        {           

            header.innerHTML = "";
            data.innerHTML = "";
            data.innerHTML = result.Data;
        }
        else
        {
        	data.innerHTML = result.Message;
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}