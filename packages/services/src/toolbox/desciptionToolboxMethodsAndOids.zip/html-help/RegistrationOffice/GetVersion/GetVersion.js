function GetVersion(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");

    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 5
        }));
    };

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);

        if (result.Success)
        {
            var header = document.getElementById(TagId + '.header');
            var data = document.getElementById(TagId + '.data');

            header.innerHTML = "";
            data.innerHTML = "";

            header.innerHTML = makeHeader(result.Data[0]);

            data.innerHTML += "<h5>Версия AstralToolBox: " + result.Data.version + "</h5>";

        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}