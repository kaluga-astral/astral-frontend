function InstallCert(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");
    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 2,
            Data: JSON.stringify({
                providerCode: document.getElementById("providerCode").value,
                providerName: document.getElementById("providerName").value,
                containerName : document.getElementById("containerName").value,
                CertData: document.getElementById("CertData").value
            })
        }));
    };

    socket.onmessage = function (msg) {
        var result = JSON.parse(msg.data);

        if (result.Success)
        {
            var header = document.getElementById(TagId + '.header');
            var data = document.getElementById(TagId + '.data');

            header.innerHTML = "";
            data.innerHTML = "";

            if (result.Data.length > 0)
            {
                header.innerHTML = makeHeader(result.Data[0]);

                result.Data.forEach((item) => {
                    data.innerHTML += makeDataLine(item);
            });
            }
        }
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');
        var data = document.getElementById(TagId + '.data');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}