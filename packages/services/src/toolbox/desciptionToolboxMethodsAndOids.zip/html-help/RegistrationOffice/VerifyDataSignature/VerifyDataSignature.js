﻿function VerifyDataSignature(TagId) {
    var socket = new WebSocket("ws://localhost:9292/RegistrationOffice");
    socket.onopen = function () {
        socket.send(JSON.stringify({
            Code: 16,
            Data: JSON.stringify({
                Base64Data: document.getElementById("Base64Data").value,
                Signature: document.getElementById("Signature").value,
                SubjectKeyId: document.getElementById("SubjectKeyId").value
            })
        }));
    };
    var data = document.getElementById(TagId + '.data');

    socket.onmessage = function (msg) {
 	
        var result = JSON.parse(msg.data);
        if(result.Success == false)
        {
        	data.innerHTML += "return: " + result.Success;           
        	data.innerHTML += "messege: " + result.Message
        }
        else
        {
        	data.innerHTML += "return: " + result.Success;           
    	}
    };

    socket.onerror = function () {
        var header = document.getElementById(TagId + '.header');

        header.innerHTML = headerItem("При обращении к приложению произошла ошибка");
        data.innderHTML = "";
    };
}