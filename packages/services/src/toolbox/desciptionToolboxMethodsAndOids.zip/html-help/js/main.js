function headerItem(str) {
    return "<th>" + str + "</th>";
}

function dataItem(str) {
    return "<td>" + str + "</td>";
}

function makeHeader(obj) {
    var str = "";
  
    for(var field in obj) {
        str += headerItem(field);
    }
    
    return str;
}

function makeDataLine(obj) {
    var str = "";
    
    for(var field in obj) {
        str += dataItem(obj[field]);
    }
    
    return str;
}
function makeKeyValueLine(obj) {
    var str = "";

    for(var field in obj) {
        str += "<tr>" + dataItem("<b>"+field+"</b>") + dataItem(obj[field]) + "</tr>";
    }

    return str;
}

function ArrayString(class_value){
    var values = document.getElementsByClassName(class_value);
        if (values.length > 0)
        {
            var value_array = [];

            for (var i = 0; i < values.length; i++) {
                value_array.push(values[i].value);
            }
        }
        return value_array;
}
function ArrayKeyValue(class_key, class_value){
        var keys = document.getElementsByClassName(class_key);
        var values = document.getElementsByClassName(class_value);

        if (keys.length > 0)
        {
            var arrayList = [];

            for (var i = 0; i < keys.length; i++) {
                arrayList.push({Oid: keys[i].value, Value: values[i].value});
            }
        }
        return arrayList;
}
function ArrayKeyValueType(class_key, class_value, class_type){
        var keys = document.getElementsByClassName(class_key);
        var values = document.getElementsByClassName(class_value);
        var types = document.getElementsByClassName(class_type);

        if (keys.length > 0)
        {
            var arrayList = [];

            for (var i = 0; i < keys.length; i++) {
                arrayList.push({Oid: keys[i].value, Value: values[i].value, Type: types[i].value});
            }
        }
        return arrayList;
}

jQuery('.plus').click(function(){
    
    jQuery('.information_json_plus').before(
    '<tr>' +
        '<td><input type="text" class="form-control oid" placeholder=""></td>' +
        '<td><input type="text" class="form-control oid-value" placeholder=""></td>' +
        '<td><span class="btn btn-danger minus pull-right">&ndash;</span></td>' +
    '</tr>'
    );

});

jQuery(document).on('click', '.minus', function(){
    jQuery( this ).closest( 'tr' ).remove(); // удаление строки с полями
});


jQuery('.plus_for_key').click(function(){
    
    jQuery('.key_json_plus').before(
    '<tr>' +
        '<td><input type="text" class="form-control keys" placeholder=""></td>' +
        '<td><span class="btn btn-danger minus_for_key pull-right">&ndash;</span></td>' +
    '</tr>'
    );

});

jQuery(document).on('click', '.minus_for_key', function(){
    jQuery( this ).closest( 'tr' ).remove(); // удаление строки с полями
});

jQuery('.plus_for_polic').click(function(){
    
    jQuery('.polic_json_plus').before(
    '<tr>' +
        '<td><input type="text" class="form-control oid-polic" placeholder=""></td>' +
        '<td><input type="text" class="form-control oid-value-polic" placeholder=""></td>' +
        '<td><span class="btn btn-danger minus_for_polic pull-right">&ndash;</span></td>' +
    '</tr>'
    );

});

jQuery(document).on('click', '.minus_for_polic', function(){
    jQuery( this ).closest( 'tr' ).remove(); // удаление строки с полями
});

jQuery('.plus_for_alter').click(function(){
    
    jQuery('.alter_json_plus').before(
    '<tr>' +
        '<td><input type="text" class="form-control type-alter" placeholder=""></td>' +
        '<td><input type="text" class="form-control oid-alter" placeholder=""></td>' +
        '<td><input type="text" class="form-control oid-value-alter" placeholder=""></td>' +
        '<td><span class="btn btn-danger minus_for_alter pull-right">&ndash;</span></td>' +
    '</tr>'
    );

});

jQuery(document).on('click', '.minus_for_alter', function(){
    jQuery( this ).closest( 'tr' ).remove(); // удаление строки с полями
});

jQuery('.plus_for_reci').click(function(){

    jQuery('.reci_json_plus').before(
        '<tr>' +
        '<td><input type="text" class="form-control reci" placeholder=""></td>' +
        '<td><span class="btn btn-danger minus_for_reci pull-right">&ndash;</span></td>' +
        '</tr>'
    );

});

jQuery(document).on('click', '.minus_for_reci', function(){
    jQuery( this ).closest( 'tr' ).remove(); // удаление строки с полями
});
